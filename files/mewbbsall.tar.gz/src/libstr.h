/*--Proto type--*/
int strspl(char *, char *, char);
char *strsub(char *, const char *, int, int);
char *replacestring(char *, char *, char *);
char *trLower(char *);
char *strhead( char *, const char *, int );
