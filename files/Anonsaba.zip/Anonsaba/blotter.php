<?php
require 'config.php';
require KU_ROOTDIR . 'inc/functions.php';

echo getBlotter(true);
?>