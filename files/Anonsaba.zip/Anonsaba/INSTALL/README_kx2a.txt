=== How to use ===

1. Copy kx2a.php and kx2a.sql to the folder containing config.php on your server.
2. Run kx2a.php.
3. Download the full version of Anonsaba from http://anonsaba.org/
4. Make a backup of your current config.php
5. Edit the Anonsaba config.php how your Kusaba config.php was.
6. Extract the files that you downloaded where you want them installed. Overwrite everything.
7. If everything went right, congratulations! You are now running Anonsaba 

