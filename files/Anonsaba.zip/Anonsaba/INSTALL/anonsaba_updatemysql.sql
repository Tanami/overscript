--- Add in the new options for boards ---

ALTER TABLE `PREFIXboards` ADD `enableads` tinyint(1) NOT NULL default '1';
ALTER TABLE `PREFIXboards` ADD `boardclass` tinyint(1) NOT NULL default '1';

--- All Done :) ---

