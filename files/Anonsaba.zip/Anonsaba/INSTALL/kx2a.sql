-- Edit the Boards --
ALTER TABLE `PREFIXboards` ADD `imgedit` tinyint(1) NOT NULL default '0';
ALTER TABLE `PREFIXboards` ADD `enableads` tinyint(1) NOT NULL default '1';
ALTER TABLE `PREFIXboards` ADD `max_files` tinyint(6) NOT NULL default '1';
ALTER TABLE `PREFIXboards` ADD `enableemail` tinyint(1) NOT NULL default '0';
ALTER TABLE `PREFIXboards` ADD `boardclass` tinyint(1) NOT NULL default '1';

CREATE TABLE IF NOT EXISTS `PREFIXpost_files` (
  `id` int(10) unsigned NOT NULL,
  `boardid` smallint(5) unsigned NOT NULL,
  `file` varchar(50) NOT NULL,
  `file_md5` char(32) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `file_original` varchar(255) NOT NULL,
  `file_size` int(20) NOT NULL default '0',
  `file_size_formatted` varchar(75) NOT NULL,
  `image_w` smallint(5) NOT NULL default '0',
  `image_h` smallint(5) NOT NULL default '0',
  `thumb_w` smallint(5) unsigned NOT NULL default '0',
  `thumb_h` smallint(5) unsigned NOT NULL default '0',
  `reviewed` tinyint(1) unsigned NOT NULL default '0',
  `IS_DELETED` tinyint(1) NOT NULL default '0',
  `timestamp` int(20) unsigned NOT NULL,
  `deleted_timestamp` int(20) NOT NULL default '0',
  KEY `id` (`id`),
  KEY `boardid` (`boardid`),
  KEY `file_md5` (`file_md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `PREFIXpost_files` SELECT `id`, `boardid`, `file`, `file_md5`, `file_type`, `file_original`, `file_size`, `file_size_formatted`, `image_w`, `image_h`, `thumb_w`, `thumb_h`, `reviewed`, `IS_DELETED`, `timestamp`, `deleted_timestamp` FROM `PREFIXposts`;

ALTER TABLE `PREFIXposts` DROP COLUMN `file`;
ALTER TABLE `PREFIXposts` DROP COLUMN `file_md5`;
ALTER TABLE `PREFIXposts` DROP COLUMN `file_type`;
ALTER TABLE `PREFIXposts` DROP COLUMN `file_original`;
ALTER TABLE `PREFIXposts` DROP COLUMN `file_size`;
ALTER TABLE `PREFIXposts` DROP COLUMN `file_size_formatted`;
ALTER TABLE `PREFIXposts` DROP COLUMN `image_w`;
ALTER TABLE `PREFIXposts` DROP COLUMN `image_h`;
ALTER TABLE `PREFIXposts` DROP COLUMN `thumb_w`;
ALTER TABLE `PREFIXposts` DROP COLUMN `thumb_h`;

-- Edit the Staff --

ALTER TABLE `PREFIXstaff` ADD `access` tinyint(1) NOT NULL default '0';
ALTER TABLE `PREFIXstaff` ADD `suspended` int(1) NOT NULL;
ALTER TABLE `PREFIXstaff` MODIFY `salt` varchar(10);

-- Edit the Embeds --

ALTER TABLE `PREFIXembeds` MODIFY `width` text(1000) COLLATE utf8_general_ci;
ALTER TABLE `PREFIXembeds` MODIFY `height` text(1000) COLLATE utf8_general_ci;

-- Add in options for Version --

CREATE TABLE `PREFIXoptions` (
 `version` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `PREFIXoptions` (`version`) VALUES ('0.1.9');

-- All Done :) --


