-- --------------------------------------------------------

--
-- Table structure for table ads
--

CREATE TABLE PREFIXads (
  id smallint NOT NULL,
  position varchar(3) NOT NULL,
  disp smallint NOT NULL,
  boards varchar(255) NOT NULL,
  code text NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table announcements
--

CREATE TABLE PREFIXannouncements (
  id serial,
  parentid int NOT NULL default '0',
  subject varchar(255) NOT NULL,
  postedat int NOT NULL,
  postedby varchar(75) NOT NULL,
  message text NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table banlist
--

CREATE TABLE PREFIXbanlist (
  id serial,
  type smallint NOT NULL default '0',
  expired smallint NOT NULL default '0',
  allowread smallint NOT NULL default '1',
  ip varchar(50) NOT NULL,
  ipmd5 char(32) NOT NULL,
  globalban smallint NOT NULL default '0',
  boards varchar(255) NOT NULL,
  by varchar(75) NOT NULL,
  at int NOT NULL,
  until int NOT NULL,
  reason text NOT NULL,
  staffnote text NOT NULL,
  appeal text NOT NULL default '',
  appealat int NOT NULL default'0',
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table bannedhashes
--

CREATE TABLE PREFIXbannedhashes (
  id serial,
  md5 varchar(255) NOT NULL,
  bantime int,
  description text NOT NULL,
  UNIQUE (id)
);

-- --------------------------------------------------------

--
-- Table structure for table blotter
--

CREATE TABLE PREFIXblotter (
  id serial,
  important smallint NOT NULL,
  at int NOT NULL,
  message text NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table boards
--

CREATE TABLE PREFIXboards (
  id serial,
  `order` smallint,
  name varchar(75) NOT NULL default '',
  type smallint NOT NULL default '0',
  boardclass smallint NOT NULL default '1',
  start int NOT NULL,
  uploadtype smallint,
  `desc` varchar(75) NOT NULL default '',
  image varchar(255) NOT NULL,
  section smallint NOT NULL default '0',
  max_files smallint NOT NULL default '1',
  maximagesize int NOT NULL default '1024000',
  maxpages int NOT NULL default '11',
  maxage int NOT NULL default '0',
  markpage smallint NOT NULL default '9',
  maxreplies int NOT NULL default '200',
  messagelength int NOT NULL default '8192',
  createdon int NOT NULL,
  locked smallint NOT NULL default '0',
  includeheader text NOT NULL default '',
  redirecttothread smallint NOT NULL default '0',
  anonymous varchar(255) NOT NULL default 'Anonymous',
  forcedanon smallint NOT NULL default '0',
  embeds_allowed varchar(255) NOT NULL default '',
  trial smallint NOT NULL default '0',
  popular smallint NOT NULL default '0',
  defaultstyle varchar(50) NOT NULL default '',
  locale varchar(30) NOT NULL default '',
  showid smallint NOT NULL default '0',
  compactlist smallint NOT NULL default '0',
  imgedit smallint NOT NULL default '0',
  enableemail smallint NOT NULL default '0',
  enableads smallint NOT NULL default '1',
  enablereporting smallint NOT NULL default '1',
  enablecaptcha smallint NOT NULL default '0',
  enablenofile smallint NOT NULL default '0',
  enablearchiving smallint NOT NULL default '0',
  enablecatalog smallint NOT NULL default '1',
  loadbalanceurl varchar(255) NOT NULL default '',
  loadbalancepassword varchar(255) NOT NULL default '',
  PRIMARY KEY (id)
);

--
-- Table structure for table board_filetypes
--

CREATE TABLE PREFIXboard_filetypes (
  boardid smallint NOT NULL default '0',
  typeid int NOT NULL default '0'
);

-- --------------------------------------------------------

--
-- Table structure for table embeds
--

CREATE TABLE PREFIXembeds (
  id serial,
  filetype varchar(3) NOT NULL,
  name varchar(255) NOT NULL,
  videourl varchar(510) NOT NULL,
  width text(1000) NOT NULL,
  height text(1000) NOT NULL,
  code text NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table events
--

CREATE TABLE PREFIXevents (
  name varchar(255) NOT NULL,
  at int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table filetypes
--

CREATE TABLE PREFIXfiletypes (
  id serial,
  filetype varchar(255) NOT NULL,
  mime varchar(255) NOT NULL default '',
  image varchar(255) NOT NULL default '',
  image_w int NOT NULL default '0',
  image_h int NOT NULL default '0',
  force_thumb int NOT NULL default '1',
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table front
--

CREATE TABLE PREFIXfront (
	id serial,
	page smallint NOT NULL default '0',
	`order` smallint NOT NULL default '0',
	subject varchar(255) NOT NULL,
	message text NOT NULL,
	timestamp int NOT NULL default '0',
	poster varchar(75) NOT NULL default '',
	email varchar(255) NOT NULL default '',
	PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table loginattempts
--

CREATE TABLE PREFIXloginattempts (
  username varchar(255) NOT NULL,
  ip varchar(20) NOT NULL,
  timestamp int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table modlog
--

CREATE TABLE PREFIXmodlog (
  entry text NOT NULL,
  `user` varchar(255) NOT NULL,
  category smallint NOT NULL default '0',
  timestamp int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table module_settings
--

CREATE TABLE PREFIXmodule_settings (
  module varchar(255) NOT NULL,
  key varchar(255) NOT NULL,
  value text NOT NULL,
  type varchar(255) NOT NULL default 'string'
);

-- --------------------------------------------------------

--
-- Table structure for table options
--

CREATE TABLE PREFIXoptions (
  version text NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table posts
--

CREATE TABLE PREFIXposts (
  id int NOT NULL,
  boardid smallint NOT NULL,
  parentid int NOT NULL default '0',
  name varchar(255) NOT NULL,
  tripcode varchar(30) NOT NULL,
  email varchar(255) NOT NULL,
  subject varchar(255) NOT NULL,
  message text NOT NULL,
  password varchar(255) NOT NULL,
  ip varchar(75) NOT NULL,
  ipmd5 char(32) NOT NULL,
  tag varchar(5) NOT NULL,
  timestamp int NOT NULL,
  stickied smallint NOT NULL default '0',
  locked smallint NOT NULL default '0',
  posterauthority smallint NOT NULL default '0',
  reviewed smallint NOT NULL default '0',
  deleted_timestamp int NOT NULL default '0',
  IS_DELETED smallint NOT NULL default '0',
  bumped int NOT NULL default '0',
  PRIMARY KEY (boardid, id)
);
  CREATE OR REPLACE FUNCTION posts_update()
    RETURNS "trigger" AS
    '
  BEGIN
  PERFORM id FROM PREFIXboards WHERE id = NEW.boardid FOR UPDATE:semicolon:
  SELECT COALESCE(MAX(id),0) + 1 INTO NEW.id FROM PREFIXposts WHERE boardid = NEW.boardid:semicolon: RETURN NEW:semicolon:
  END
    '
  LANGUAGE 'plpgsql';
  CREATE TRIGGER posts_trigger BEFORE INSERT on PREFIXposts FOR EACH ROW EXECUTE PROCEDURE posts_update();
  CREATE INDEX parentid ON PREFIXposts (parentid);
  CREATE INDEX bumped ON PREFIXposts (bumped);
  CREATE INDEX stickied ON PREFIXposts (stickied);

-- --------------------------------------------------------

--
-- Table structure for table post_files
--

CREATE TABLE PREFIXpost_files (
  id int NOT NULL,
  boardid smallint NOT NULL,
  file varchar(50) NOT NULL,
  file_md5 char(32) NOT NULL,
  file_type varchar(20) NOT NULL,
  file_original varchar(255) NOT NULL,
  file_size int NOT NULL default '0',
  file_size_formatted varchar(75) NOT NULL,
  image_w smallint NOT NULL default '0',
  image_h smallint NOT NULL default '0',
  thumb_w smallint NOT NULL default '0',
  thumb_h smallint NOT NULL default '0',
  timestamp int NOT NULL,
  reviewed smallint NOT NULL default '0',
  deleted_timestamp int NOT NULL default '0',
  IS_DELETED smallint NOT NULL default '0',
  PRIMARY KEY (boardid, id, file_md5)
);
  CREATE OR REPLACE FUNCTION posts_update()
    RETURNS "trigger" AS
    '
  BEGIN
  PERFORM id FROM PREFIXboards WHERE id = NEW.boardid FOR UPDATE:semicolon:
  SELECT COALESCE(MAX(id),0) + 1 INTO NEW.id FROM PREFIXpost_files WHERE boardid = NEW.boardid:semicolon: RETURN NEW:semicolon:
  END
    '
  LANGUAGE 'plpgsql';
  CREATE TRIGGER posts_trigger BEFORE INSERT on PREFIXposts FOR EACH ROW EXECUTE PROCEDURE posts_update();
  CREATE INDEX id ON PREFIXpost_files (id);
  CREATE INDEX boardid ON PREFIXpost_files (boardid);
  CREATE INDEX file_md5 On PREFIXpost_files (file_md5);


-- --------------------------------------------------------

--
-- Table structure for table reports
--

CREATE TABLE PREFIXreports (
  id serial,
  cleared smallint NOT NULL default '0',
  board varchar(255) NOT NULL,
  postid int NOT NULL,
  `when` int NOT NULL,
  ip varchar(75) NOT NULL,
  reason varchar(255) NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table sections
--

CREATE TABLE PREFIXsections (
  id serial,
  `order` smallint,
  hidden smallint NOT NULL default '0',
  name varchar(255) NOT NULL NOT NULL default '0',
  abbreviation varchar(10) NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table staff
--

CREATE TABLE PREFIXstaff (
  id serial,
  username varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  salt varchar(10) NOT NULL,
  type smallint NOT NULL default '0',
  boards text,
  addedon int NOT NULL,
  lastactive int NOT NULL default '0',
  suspended int NOT NULL,
  access smallint NOT NULL default '0',
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table watchedthreads
--

CREATE TABLE PREFIXwatchedthreads (
  id serial,
  threadid int NOT NULL,
  board varchar(255) NOT NULL,
  ip char(15) NOT NULL,
  lastsawreplyid int NOT NULL,
  PRIMARY KEY (id)
);

-- --------------------------------------------------------

--
-- Table structure for table wordfilter
--

CREATE TABLE PREFIXwordfilter (
  id serial,
  word varchar(75) NOT NULL,
  replacedby varchar(75) NOT NULL,
  boards text NOT NULL,
  time int NOT NULL,
  regex smallint NOT NULL default '0',
  PRIMARY KEY (id)
);


CREATE OR REPLACE FUNCTION "if"(boolean, integer, integer) RETURNS integer AS
      'SELECT CASE WHEN $1 THEN $2 ELSE $3 END:semicolon:'
      LANGUAGE 'sql';
INSERT INTO `PREFIXads` (`id`, `position`, `disp`, `boards`, `code`) VALUES (1, 'top', 0, '', 'Right Frame Top');
INSERT INTO `PREFIXads` (`id`, `position`, `disp`, `boards`, `code`) VALUES (2, 'bot', 0, '', 'Right Frame Bottom');
INSERT INTO `PREFIXoptions` (`version`) VALUES ('0.1.9');
INSERT INTO `PREFIXfiletypes` (`filetype`, `force_thumb`) VALUES ('jpg', 0);
INSERT INTO `PREFIXfiletypes` (`filetype`, `force_thumb`) VALUES ('gif', 0);
INSERT INTO `PREFIXfiletypes` (`filetype`, `force_thumb`) VALUES ('png', 0) ;
INSERT INTO `PREFIXevents` (`name`, `at`) VALUES ('pingback', 0);
INSERT INTO `PREFIXevents` (`name`, `at`) VALUES ('sitemap', 0);
INSERT INTO `PREFIXembeds` (`filetype`, `name`, `videourl`, `width`, `height`, `code`) VALUES ('you', 'Youtube', 'http://www.youtube.com/watch?v=', 200, 164, '<object type="application/x-shockwave-flash" width="SET_WIDTH" height="SET_HEIGHT" data="http://www.youtube.com/v/EMBED_ID"> <param name="movie" value="http://www.youtube.com/v/EMBED_ID" /> </object>');
INSERT INTO `PREFIXembeds` (`filetype`, `name`, `videourl`, `width`, `height`, `code`) VALUES ('goo', 'Google', 'http://video.google.com/videoplay?docid=', 200, 164, '<embed width="SET_WIDTH" height="SET_HEIGHT" id="VideoPlayback" type="application/x-shockwave-flash" src="http://video.google.com/googleplayer.swf?docId=EMBED_ID"></embed>');
