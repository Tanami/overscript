#============================================================================================================
#
#	bbs.cgi�x�����W���[��(VARDA)
#	varda.pl
#	---------------------------------------------
#	2003.02.06 start
#	2004.03.31 ���e�ύX
#
#============================================================================================================
package	VARDA;

#------------------------------------------------------------------------------------------------------------
#
#	�R���X�g���N�^
#	-------------------------------------------------------------------------------------
#	@param	�Ȃ�
#	@return	���W���[���I�u�W�F�N�g
#
#------------------------------------------------------------------------------------------------------------
sub new
{
	my		$this = shift;
	my		$obj = {};
	
	$obj = {
		'SYS'		=> undef,
		'SET'		=> undef,
		'THREADS'	=> undef,
		'CONV'		=> undef,
		'BANNER'	=> undef,
		'CODE'		=> undef
	};
	bless($obj,$this);
	
	return $obj;
}

#------------------------------------------------------------------------------------------------------------
#
#	������
#	-------------------------------------------------------------------------------------
#	@param	$Sys		MELKOR
#	@param	$Setting	ISILDUR
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub Init
{
	my		$this = shift;
	my		($Sys,$Setting) = @_;
	
	require('./module/baggins.pl');
	require('./module/galadriel.pl');
	require('./module/denethor.pl');
	
	# �g�p���W���[����ݒ�
	$this->{'SYS'}		= $Sys;
	$this->{'THREADS'}	= new BILBO;
	$this->{'CONV'}		= new GALADRIEL;
	$this->{'BANNER'}	= new DENETHOR;
	$this->{'CODE'}		= 'sjis';
	
	if	($Setting eq undef){
		require('./module/isildur.pl');
		$this->{'SET'} = new ISILDUR;
		$this->{'SET'}->Load($Sys);
	}
	else{
		$this->{'SET'} = $Setting;
	}
	
	# ���̓ǂݍ���
	$this->{'THREADS'}->Load($Sys);
	$this->{'BANNER'}->Load($Sys);
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����
#	-------------------------------------------------------------------------------------
#	@param	�Ȃ�
#	@return	�������ꂽ��1��Ԃ�
#
#------------------------------------------------------------------------------------------------------------
sub CreateIndex
{
	my		$this = shift;
	my		($Sys,$Thread,$bbsSetting,$Index,$Caption);
	my		($path,$i);
	
	$Sys		= $this->{'SYS'};
	$Threads 	= $this->{'THREADS'};
	$bbsSetting	= $this->{'SET'};
	
	# CREATE���[�h�A�܂��̓X���b�h��index�\���͈͓��̏ꍇ�̂�index���X�V����
	if	($Sys->Equal('MODE','CREATE')
		|| ($Threads->GetPosition($Sys->Get('KEY')) < $bbsSetting->Get('BBS_MAX_MENU_THREAD'))){
		
		require('./module/thorin.pl');
		require('./module/legolas.pl');
		$Index = new THORIN;
		$Caption = new LEGOLAS;
		
		PrintIndexHead($this,$Index,$Caption);
		PrintIndexMenu($this,$Index);
		PrintIndexPreview($this,$Index);
		PrintIndexFoot($this,$Index,$Caption);
		
		$path = $Sys->Get('BBSPATH') . '/' . $Sys->Get('BBS') . '/index.html';
		$Index->Flush(1,$Sys->Get('PM-TXT'),$path);
		
		return 1;
	}
	return 0;
}

#------------------------------------------------------------------------------------------------------------
#
#	i/index.html����
#	-------------------------------------------------------------------------------------
#	@param	�Ȃ�
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub CreateIIndex
{
	my		$this = shift;
	my		($Sys,$Thread,$bbsSetting,$oConv,$Page);
	my		($path,$i,$name,$key,$res,$cgiPath,$title,$menuNum,$code);
	my		(@threadSet);
	
	require('./module/thorin.pl');
	$Page = new THORIN;
	
	# �O����
	$Sys		= $this->{'SYS'};
	$Threads 	= $this->{'THREADS'};
	$bbsSetting	= $this->{'SET'};
	$oConv		= $this->{'CONV'};
	
	$cgiPath	= $Sys->Get('SERVER') . $Sys->Get('CGIPATH');
	$title		= $bbsSetting->Get('BBS_TITLE');
	$menuNum	= $bbsSetting->Get('BBS_MAX_MENU_THREAD');
	$code		= $this->{'CODE'};
	$i			= 1;
	$bbs		= $Sys->Get('BBS');
	
	# �S�X���b�h���擾
	$Threads->GetKeySet('ALL','',\@threadSet);
	
	# HTML�w�b�_�̏o��
	$Page->Print('<html><!--nobanner--><head><title>' . $title . '</title>');
	$Page->Print('<meta http-equiv=Content-Type content="text/html;charset=' . $code . '">');
	$Page->Print('</head><body><center>' . $title . '</center>');
	
	# �o�i�[�\��
	$this->{'BANNER'}->Print($Page,100,1,1);
	$Page->Print('<hr></center>');
	
	# �X���b�h���������[�v���܂킷
	foreach	$key (@threadSet){
		if	($i > $menuNum){
			last;
		}
		$name	= $Threads->Get('SUBJECT',$key);
		$res	= $Threads->Get('RES',$key);
		$path	= $oConv->CreatePath($Sys,1,$bbs,$key,'l10');
		
		$Page->Print("<a href=\"$path\">$i: $name($res)</a><br> \n");
		$i++;
	}
	
	# �t�b�^�����̏o��
	$path = "$cgiPath/p.cgi?bbs=$bbs&st=$i";
	$Page->Print("<hr><a href=\"$cgiPath/bbs.cgi?bbs=$bbs&mobile=true\">");
	$Page->Print("�X���b�h�쐬</a> <a href=\"$path\">����</a><hr></body></html>\n");
	
	# i/index.html�ɏ�������
	$path = $Sys->Get('BBSPATH') . '/' . $bbs;
	$Page->Flush(1,$Sys->Get('PM-TXT'),"$path/i/index.html");
}

#------------------------------------------------------------------------------------------------------------
#
#	subback.html����
#	-------------------------------------------------------------------------------------
#	@param	�Ȃ�
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub CreateSubback
{
	my		$this = shift;
	my		($Sys,$Thread,$bbsSetting,$oConv,$Page);
	my		($path,$i,$name,$key,$res,$cgiPath,$title,$code);
	my		(@threadSet,$max);
	
	require('./module/thorin.pl');
	$Page = new THORIN;
	
	$Sys		= $this->{'SYS'};
	$Threads 	= $this->{'THREADS'};
	$bbsSetting	= $this->{'SET'};
	$oConv		= $this->{'CONV'};
	
	$cgiPath	= $Sys->Get('SERVER') . $Sys->Get('CGIPATH');
	$title		= $bbsSetting->Get('BBS_TITLE');
	$code		= $this->{'CODE'};
	$i			= 1;
	$bbs		= $Sys->Get('BBS');
	$max		= $Sys->Get('SUBMAX');
	
	# �S�X���b�h���擾
	$Threads->GetKeySet('ALL','',\@threadSet);
	
	# HTML�w�b�_�̏o��
	$Page->Print('<html><!--nobanner--><head><title>' . $title . '</title>');
	$Page->Print('<meta http-equiv=Content-Type content="text/html;charset=' . $code . '">');
	$Page->Print('</head><body bgcolor=#FFFFFF><small>');
	
	# �o�i�[�\��
	$this->{'BANNER'}->Print($Page,100,2,0);
	
	# �X���b�h���������[�v���܂킷
	foreach	$key (@threadSet){
		if($i > $max){
			last;
		}
		$name	= $Threads->Get('SUBJECT',$key);
		$res	= $Threads->Get('RES',$key);
		$path	= $oConv->CreatePath($Sys,0,$bbs,$key,'l50');
		
		$Page->Print("<a href=\"$path\" target=_blank>$i:$name($res)</a>�@\n");
		$i++;
	}
	
	# �t�b�^�����̏o��
	$Page->Print("<div align=right><a href=\"./kako/index.html\" target=_blank><b>");
	$Page->Print("�ߋ����O�q�ɂ͂�����</b></a></div></small></body></html>\n");
	
	# subback.html�ɏ�������
	$path = $Sys->Get('BBSPATH') . '/' . $bbs;
	$Page->Flush(1,$Sys->Get('PM-TXT'),"$path/subback.html");
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(�w�b�_����)
#	-------------------------------------------------------------------------------------
#	@param	$Page		
#	@param	$Caption	
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintIndexHead
{
	my		($this,$Page,$Caption) = @_;
	my		($title,$link,$image,$code);
	
	$Caption->Load($this->{'SYS'},'META');
	$title	= $this->{'SET'}->Get('BBS_TITLE');
	$link	= $this->{'SET'}->Get('BBS_TITLE_LINK');
	$image	= $this->{'SET'}->Get('BBS_TITLE_PICTURE');
	$code	= $this->{'CODE'};
	
	# HTML�w�b�_�̏o��
	$Page->Print('<html><head><title>' . $title . '</title>');
	$Caption->Print($Page,undef);
	$Page->Print('<meta http-equiv=Content-Type content="text/html;charset=' . $code . '">');
	
	# cookie�pscript�̏o��
	if	($this->{'SET'}->Equal('SUBBBS_CGI_ON',1)){
		require('./module/radagast.pl');
		RADAGAST::Print(undef,$Page);
	}
	$Page->Print('</head><!--nobanner-->');
	
	# <body>�^�O�o��
	{
		my	@work;
		$work[0] = $this->{'SET'}->Get('BBS_BG_COLOR');
		$work[1] = $this->{'SET'}->Get('BBS_TEXT_COLOR');
		$work[2] = $this->{'SET'}->Get('BBS_LINK_COLOR');
		$work[3] = $this->{'SET'}->Get('BBS_ALINK_COLOR');
		$work[4] = $this->{'SET'}->Get('BBS_VLINK_COLOR');
		$work[5] = $this->{'SET'}->Get('BBS_BG_PICTURE');
		
		$Page->Print("<body bgcolor=$work[0] text=$work[1] link=$work[2] ");
		$Page->Print("alink=$work[3] vlink=$work[4] ");
		$Page->Print("background=\"$work[5]\">\n");
	}
	$Page->Print('<center><a name="top" />');
	
	# �Ŕ摜�\������
	if	($image ne ''){
		# �Ŕ摜����̃����N����
		if	($link ne ''){
			$Page->Print("<a href=\"$link\"><img src=\"$image\" border=0 /></a><br>");
		}
		# �Ŕ摜�Ƀ����N�͂Ȃ�
		else{
			$Page->Print("<img src=\"$image\" border=0 /><br>");
		}
	}
	
	# �w�b�_�e�[�u���̕\��
	$Caption->Load($this->{'SYS'},'HEAD');
	$Caption->Print($Page,$this->{'SET'});
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(�X���b�h���j���[����)
#	-------------------------------------------------------------------------------------
#	@param	$Page		
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintIndexMenu
{
	my		($this,$Page) = @_;
	my		($Conv,$menuCol,$menuNum,$prevNum,$i);
	my		(@threadSet,$key,$name,$res,$path,$max);
	
	$Conv		= $this->{'CONV'};
	$menuCol	= $this->{'SET'}->Get('BBS_MENU_COLOR');
	$menuNum	= $this->{'SET'}->Get('BBS_MAX_MENU_THREAD');
	$prevNum	= $this->{'SET'}->Get('BBS_THREAD_NUMBER');
	$i			= 1;
	$max		= $this->{'SYS'}->Get('SUBMAX');
	
	$this->{'THREADS'}->GetKeySet('ALL','',\@threadSet);
	
	# �o�i�[�̕\��
	$this->{'BANNER'}->Print($Page,95,0,0);
	
	$Page->Print('<br><a name="menu" /><table border=1 cellspacing=7 cellpadding=3');
	$Page->Print(" width=95% bgcolor=$menuCol><tr><td><small>\n");
	
	# �X���b�h���������[�v���܂킷
	foreach	$key (@threadSet){
		if	(($i > $menuNum) || ($i > $max)){
			last;
		}
		$name	= $this->{'THREADS'}->Get('SUBJECT',$key);
		$res	= $this->{'THREADS'}->Get('RES',$key);
		$path	= $Conv->CreatePath($this->{'SYS'},0,$this->{'SYS'}->Get('BBS'),$key,'l50');
		
		# �v���r���[�X���b�h�̏ꍇ�̓v���r���[�ւ̃����N��\��
		if	($i < $prevNum){
			$Page->Print("<a href=\"$path\" target=\"body\">$i:</a> ");
			$Page->Print("<a href=\"#$i\">$name($res)</a>�@");
		}
		else{
			$Page->Print("<a href=\"$path\" target=\"body\">$i: $name($res)</a>�@");
		}
		$i++;
	}
	$Page->Print("<div align=right><b><a href=\"./subback.html\">");
	$Page->Print('�X���b�h�ꗗ�͂�����</a></b></div></small></td></tr>');
	$Page->Print("</table><br>\n");
	
	# �T�u�o�i�[�̕\��(�\���������s���ЂƂ}��)
	if	($this->{'BANNER'}->PrintSub($Page)){
		$Page->Print('<br>');
	}
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(�X���b�h�v���r���[����)
#	-------------------------------------------------------------------------------------
#	@param	$Page		
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintIndexPreview
{
	my		($this,$Page) = @_;
	my		($oDat,$oConv,@threadSet,$Plugin);
	my		($prevNum,$threadNum,$prevT,$nextT,$tblCol,$ttlCol);
	my		($basePath,$datPath,$cnt,$subject,$res,$key,$max);
	
	# �g���@�\���[�h
	require('./module/athelas.pl');
	$Plugin = new ATHELAS;
	$Plugin->Load($this->{'SYS'});
	
	# �L���Ȋg���@�\�ꗗ���擾
	my	(@pluginSet,@commands,$id,$count);
	$Plugin->GetKeySet('VALID',1,\@pluginSet);
	$count = 0;
	foreach $id (@pluginSet){
		# �^�C�v��read.cgi�̏ꍇ�̓��[�h���Ď��s
		if($Plugin->Get('TYPE',$id) & 8){
			my $file = $Plugin->Get('FILE',$id);
			my $className = $Plugin->Get('CLASS',$id);
			if(-e "./plugin/$file"){
				require("./plugin/$file");
				$commands[$count] = new $className;
				$count++;
			}
		}
	}
	
	require('./module/gondor.pl');
	$oDat = new ARAGORN;
	
	$this->{'THREADS'}->GetKeySet('ALL','',\@threadSet);
	
	# �O����
	$prevNum	= $this->{'SET'}->Get('BBS_THREAD_NUMBER');
	$threadNum	= (@threadSet > $prevNum ? $prevNum : @threadSet);
	$tblCol		= $this->{'SET'}->Get('BBS_THREAD_COLOR');
	$ttlCol		= $this->{'SET'}->Get('BBS_SUBJECT_COLOR');
	$prevT		= $threadNum;
	$nextT		= ($threadNum > 1 ? 2 : 1);
	$oConv		= $this->{'CONV'};
	$basePath	= $this->{'SYS'}->Get('BBSPATH') . '/' . $this->{'SYS'}->Get('BBS');
	$cnt		= 1;
	$max		= $this->{'SYS'}->Get('SUBMAX');
	
	foreach	$key (@threadSet){
		if	(($cnt > $prevNum) || ($cnt > $max)){
			last;
		}
		$subject	= $this->{'THREADS'}->Get('SUBJECT',$key);
		$res		= $this->{'THREADS'}->Get('RES',$key);
		$nextT		= 1	if	($cnt == $threadNum);
		
		# �w�b�_�����̕\��
		$Page->Print('<table border=1 cellspacing=7 cellpadding=3 width=95% ');
		$Page->Print("bgcolor=$tblCol><tr><td><dl><a name=\"$cnt\"></a>");
		$Page->Print('<div align=right><a href="#menu">��</a>');
		$Page->Print("<a href=\"#$prevT\">��</a><a href=\"#$nextT\">��</a>\n");
		$Page->Print("</div><b>�y$cnt:$res�z<font size=+2 color=$ttlCol>$subject");
		$Page->Print('</font></b>');
		
		# �v���r���[�̕\��
		$datPath = $basePath . '/dat/' . $key . '.dat';
		$oDat->Load($this->{'SYS'},$datPath,1);
		$this->{'SYS'}->Set('KEY',$key);
		PrintThreadPreviewOne($this,$Page,$oDat,\@commands);
		$oDat->Close();
		
		# �t�b�^�����̕\��
		{
			my	($allPath,$lastPath,$numPath);
			
			$allPath	= $oConv->CreatePath($this->{'SYS'},0,$this->{'SYS'}->Get('BBS'),$key,'');
			$lastPath	= $oConv->CreatePath($this->{'SYS'},0,$this->{'SYS'}->Get('BBS'),$key,'l50');
			$numPath	= $oConv->CreatePath($this->{'SYS'},0,$this->{'SYS'}->Get('BBS'),$key,'1-100');
			
			$Page->Print("<b><a href=\"$allPath\">�S���ǂ�</a> ");
			$Page->Print("<a href=\"$lastPath\">�ŐV50</a> ");
			$Page->Print("<a href=\"$numPath\">1-100</a> ");
			$Page->Print('<a href="#top">�̃g�b�v</a> ');
			$Page->Print('<a href="./index.html">�����[�h</a>');
			$Page->Print("</ul></form></dl></td></tr></table><br>\n");
		}
		
		# �J�E���^�̍X�V
		$nextT++;
		$prevT++;
		$prevT = 1	if	($cnt == 1);
		$cnt++;
	}
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(�t�b�^����)
#	-------------------------------------------------------------------------------------
#	@param	$Page		
#	@param	$Caption	
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintIndexFoot
{
	my		($this,$Page,$Caption) = @_;
	my		($SYS,$tblCol,$cgiPath,$bbs,$ver,$tm);
	
	$SYS		= $this->{'SYS'};
	$tblCol		= $this->{'SET'}->Get('BBS_MAKETHREAD_COLOR');
	$cgiPath	= $SYS->Get('SERVER') . $SYS->Get('CGIPATH');
	$bbs		= $SYS->Get('BBS');
	$ver		= $SYS->Get('VERSION');
	$tm			= time;
	
	# �X���b�h�쐬��ʂ�ʉ�ʂŕ\��
	if	($this->{'SET'}->Equal('BBS_PASSWORD_CHECK','checked')){
		$Page->Print("<form method=\"POST\" action=\"$cgiPath/bbs.cgi\">");
		$Page->Print('<table border=1 cellspacing=7 cellpadding=3 width=95% ');
		$Page->Print("bgcolor=$tblCol><tr><td><b>�X���b�h�V�K�쐬</b><br>");
		$Page->Print('<input type="submit" value=" �V�K�X���b�h�쐬��ʂ� ">');
		$Page->Print("<br><input type=\"hidden\" name=bbs value=$bbs>\n");
		$Page->Print("<input type=\"hidden\" name=time value=$tm>\n");
		$Page->Print('</td></tr></table></form>');
	}
	# �X���b�h�쐬�t�H�[����index�Ɠ�����ʂɕ\��
	else{
		$Page->Print('<table border=1 cellspacing=7 cellpadding=3 width=95% ');
		$Page->Print("bgcolor=$tblCol><tr><td><b>�X���b�h�V�K�쐬</b><br><center>");
		$Page->Print("<form method=\"POST\" action=\"$cgiPath/bbs.cgi\">");
		$Page->Print("<input type=\"hidden\" name=\"bbs\" value=\"$bbs\">");
		$Page->Print("<input type=\"hidden\" name=\"time\" value=\"$tm\">");
		$Page->Print('<table border=0><tr><td>');
		$Page->Print('�^�C�g���F<input type="text" name="subject" size=25>�@');
		$Page->Print('<input type="submit" value="�V�K�X���b�h�쐬"><br>');
		$Page->Print('���O<font size=1>�i�ȗ��j</font>�F');
		$Page->Print("<input type=\"text\" name=\"FROM\" size=19 value=\"\"> ");
		$Page->Print("E-mail<font size=1>�i�ȗ��j</font>�F");
		$Page->Print("<input type=\"text\" name=\"mail\" size=19 value=\"\"><br>");
		$Page->Print('<textarea rows=5 cols=64 wrap=off name="MESSAGE">');
		$Page->Print("</textarea></td></tr></table></form></center>$ver</td></tr>");
		$Page->Print('</table>');
	}
	
	# foot�̕\��
	$Caption->Load($this->{'SYS'},'FOOT');
	$Caption->Print($Page,$this->{'SET'});
	
	$Page->Print("</body></html>\n");
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(�X���b�h�v���r���[����)
#	-------------------------------------------------------------------------------------
#	@param	$this	
#	@param	$Page	
#	@param	$oDat	
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintThreadPreviewOne
{
	my		($this,$Page,$oDat,$commands) = @_;
	my		($pDat,$contNum,$start,$end,$i,$cgiPath,$bbs,$tm,$key);
	
	# �O����
	$contNum	= $this->{'SET'}->Get('BBS_CONTENTS_NUMBER');
	$cgiPath	= $this->{'SYS'}->Get('SERVER') . $this->{'SYS'}->Get('CGIPATH');
	$bbs		= $this->{'SYS'}->Get('BBS');
	$key		= $this->{'SYS'}->Get('KEY');
	$tm			= time;
	
	# �\�����̐��K��
	($start,$end) = $this->{'CONV'}->RegularDispNum(
						$this->{'SYS'},$oDat,1,$contNum,$contNum);
	if	($start == 1){
		$start++;
	}
	
	# 1�̕\��
	PrintResponse($this,$Page,$oDat,$commands,1);
	# �c��̕\��
	for	($i = $start;$i <= $end;$i++){
		PrintResponse($this,$Page,$oDat,$commands,$i);
	}
	
	# �������݃t�H�[���̕\��
	$Page->Print("<form method=\"POST\" action=\"$cgiPath/bbs.cgi\">");
	$Page->Print("<input type=hidden name=\"bbs\" value=\"$bbs\">");
	$Page->Print("<input type=hidden name=\"key\" value=\"$key\">");
	$Page->Print("<input type=hidden name=\"time\" value=\"$tm\">");
	$Page->Print("<input type=submit value=\"��������\" name=submit> ");
	$Page->Print("���O�F<input type=text name=\"FROM\" size=19>");
	$Page->Print(" E-mail�F<input type=text name=\"mail\" size=19><br><ul>");
	$Page->Print("<textarea rows=5 cols=64 wrap=off name=\"MESSAGE\"></textarea>");
	$Page->Print("<br>\n");
}

#------------------------------------------------------------------------------------------------------------
#
#	index.html����(���X�\������)
#	-------------------------------------------------------------------------------------
#	@param	$this	
#	@param	$Page	
#	@param	$oDat	
#	@param	$n		
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub PrintResponse
{
	my		($this,$Page,$oDat,$commands,$n) = @_;
	my		($oConv,@elem,$contLen,$contLine,$nameCol,$dispLine);
	my		($pDat,$command);
	
	$oConv		= $this->{'CONV'};
	$pDat		= $oDat->Get($n - 1);
	@elem		= split(/<>/,$$pDat);
	$contLen	= length($elem[3]);
	$contLine	= $oConv->GetTextLine(\$elem[3]);
	$nameCol	= $this->{'SET'}->Get('BBS_NAME_COLOR');
	$dispLine	= $this->{'SET'}->Get('BBS_LINE_NUMBER');
	
	# URL�ƈ��p���̓K��
	$oConv->ConvertURL($this->{'SYS'},$this->{'SET'},0,\$elem[3]);
	$oConv->ConvertQuotation($this->{'SYS'},\$elem[3],0);
	
	# �g���@�\�����s
	$this->{'SYS'}->Set('_DAT_',\@elem);
	$this->{'SYS'}->Set('_NUM_',$n);
	foreach $command (@$commands){
		$command->execute($this->{'SYS'},undef,8);
	}
	
	$Page->Print("<dt>$n ���O�F");
	
	# ���[�����L��
	if	($elem[1] eq ""){
		$Page->Print("<font color=$nameCol><b>$elem[0]</b></font>");
	}
	# ���[��������
	else{
		$Page->Print("<a href=\"mailto:$elem[1]\"><b>$elem[0]</b></a>");
	}
	
	# �\���s�����Ȃ炷�ׂĕ\������
	if	($contLine <= $dispLine || $n == 1){
		$Page->Print("�F$elem[2]</dt><dd>$elem[3]<br><br></dd>\n");
	}
	# �\���s���𒴂�����ȗ��\����t������
	else{
		my		(@dispBuff,$path,$k);
		
		@dispBuff	= split(/<br>|<BR>/,$elem[3]);
		$path		= $oConv->CreatePath($this->{'SYS'},0,$this->{'SYS'}->Get('BBS'),
											$this->{'SYS'}->Get('KEY'),"${n}n");
		
		$Page->Print("�F$elem[2]</dt><dd>");
		for	($k = 0;$k < $dispLine;$k++){
			$Page->Print("$dispBuff[$k]<br>");
		}
		$Page->Print('<font color=green>�i�ȗ�����܂����E�E�S�Ă�ǂނɂ�');
		$Page->Print("<a href=\"$path\" target=_blank>������</a>");
		$Page->Print("�������Ă��������j</font><br><br></dd>\n");
	}
}

#============================================================================================================
#	Module END
#============================================================================================================
1;
