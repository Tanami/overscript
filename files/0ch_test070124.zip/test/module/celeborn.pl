#============================================================================================================
#
#	�ߋ����O�Ǘ����W���[��(CELEBORN)
#	celeborn.pl
#	-------------------------------------------------------------------------------------
#	2003.01.22 start
#	2003.03.07 Make���\�b�h�ǉ�
#	2004.08.24 �č\�z
#
#============================================================================================================
package	CELEBORN;

#------------------------------------------------------------------------------------------------------------
#
#	�R���X�g���N�^
#	-------------------------------------------------------------------------------------
#	@param	�Ȃ�
#	@return	���W���[���I�u�W�F�N�g
#
#------------------------------------------------------------------------------------------------------------
sub new
{
	my		$this = shift;
	my		(%KAKO,$PATH,$obj);
	
	$obj = {
		'KEY'		=> undef,
		'SUBJECT'	=> undef,
		'DATE'		=> undef,
		'PATH'		=> undef
	};
	bless $obj,$this;
	
	return $obj;
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����O���t�@�C���ǂݍ���
#	-------------------------------------------------------------------------------------
#	@param	$SYS	MELKOR
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub Load
{
	my		$this = shift;
	my		($SYS) = @_;
	my		(@elem,$path);
	
	undef($this->{'KEY'});
	undef($this->{'SUBJECT'});
	undef($this->{'DATE'});
	undef($this->{'PATH'});
	
	$path = $SYS->Get('BBSPATH') . '/' . $SYS->Get('BBS') . '/kako/kako.idx';
	
	if	(-e $path){
		open(KAKO,"<$path");
		while	(<KAKO>){
			chomp($_);
			@elem = split(/<>/,$_);
			$this->{'KEY'}->{$elem[0]}		= $elem[1];
			$this->{'SUBJECT'}->{$elem[0]}	= $elem[2];
			$this->{'DATE'}->{$elem[0]}		= $elem[3];
			$this->{'PATH'}->{$elem[0]}		= $elem[4];
		}
		close(KAKO);
		return 0;
	}
	return -1;
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����O���t�@�C����������
#	-------------------------------------------------------------------------------------
#	@param	$SYS	MELKOR
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub Save
{
	my		$this = shift;
	my		($SYS) = @_;
	my		($path,$data);
	
	$path = $SYS->Get('BBSPATH') . '/' . $SYS->Get('BBS') . '/kako/kako.idx';
	
	eval{
		open(KAKO,"+>$path");
		flock(KAKO,2);
		binmode(KAKO);
		truncate(KAKO,0);
		seek(KAKO,0,0);
		foreach	(keys %{$this->{'SUBJECT'}}){
			$data = $_ . '<>' . $this->{KEY}->{$_};
			$data = $data . '<>' . $this->{SUBJECT}->{$_};
			$data = $data . '<>' . $this->{DATE}->{$_};
			$data = $data . '<>' . $this->{PATH}->{$_};
			
			print KAKO "$data\n";
		}
		close(KAKO);
		chmod($SYS->Get('PM-DAT'),$path);
	};
}

#------------------------------------------------------------------------------------------------------------
#
#	ID�Z�b�g�擾
#	-------------------------------------------------------------------------------------
#	@param	$kind	�������
#	@param	$name	�������[�h
#	@param	$pBuf	ID�Z�b�g�i�[�o�b�t�@
#	@return	�L�[�Z�b�g��
#
#------------------------------------------------------------------------------------------------------------
sub GetKeySet
{
	my		$this = shift;
	my		($kind,$name,$pBuf) = @_;
	my		($key,$n);
	
	$n = 0;
	
	if	($kind eq 'ALL'){
		foreach	$key (keys %{$this->{'KEY'}}){
			if	($this->{'KEY'}->{$key} ne '0'){
				push(@$pBuf,$key);
				$n++;
			}
		}
	}
	else{
		foreach	$key (keys %{$this->{$kind}}){
			if	(($this->{$kind}->{$key} eq $name) || ($kind eq 'ALL')){
				push(@$pBuf,$key);
				$n++;
			}
		}
	}
	
	return $n;
}

#------------------------------------------------------------------------------------------------------------
#
#	���擾
#	-------------------------------------------------------------------------------------
#	@param	$kind	�����
#	@param	$key	���[�UID
#	@return	���[�U���
#
#------------------------------------------------------------------------------------------------------------
sub Get
{
	my		$this = shift;
	my		($kind,$key) = @_;
	
	return $this->{$kind}->{$key};
}

#------------------------------------------------------------------------------------------------------------
#
#	�ǉ�
#	-------------------------------------------------------------------------------------
#	@param	$key		�X���b�h�L�[
#	@param	$subject	�X���b�h�^�C�g��
#	@param	$date		�X�V����
#	@return	ID
#
#------------------------------------------------------------------------------------------------------------
sub Add
{
	my		$this = shift;
	my		($key,$subject,$date,$path) = @_;
	my		($id);
	
	$id = time();
	while	(exists($this->{'KEY'}->{$id})){
		$id ++;
	}
	$this->{'KEY'}->{$id}		= $key;
	$this->{'SUBJECT'}->{$id}	= $subject;
	$this->{'DATE'}->{$id}		= $date;
	$this->{'PATH'}->{$id}		= $path;
	
	return $id;
}

#------------------------------------------------------------------------------------------------------------
#
#	���ݒ�
#	-------------------------------------------------------------------------------------
#	@param	$id		ID
#	@param	$kind	�����
#	@param	$val	�ݒ�l
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub Set
{
	my		$this = shift;
	my		($id,$kind,$val) = @_;
	
	if	(exists($this->{$kind}->{$id})){
		$this->{$kind}->{$id} = $val;
	}
}

#------------------------------------------------------------------------------------------------------------
#
#	���폜
#	-------------------------------------------------------------------------------------
#	@param	$id		�폜ID
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub Delete
{
	my		$this = shift;
	my		($id) = @_;
	
	delete($this->{'KEY'}->{$id});
	delete($this->{'SUBJECT'}->{$id});
	delete($this->{'DATE'}->{$id});
	delete($this->{'PATH'}->{$id});
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����O���̍X�V
#	-------------------------------------------------------------------------------------
#	@param	$Sys	MELKOR
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub UpdateInfo
{
	my		$this = shift;
	my		($Sys) = @_;
	my		(%Dirs,@dirList,@fileList,@elem);
	my		($dir,$filr,$path,$subj);
	
	require('./module/earendil.pl');
	
	undef($this->{'KEY'});
	undef($this->{'SUBJECT'});
	undef($this->{'DATE'});
	undef($this->{'PATH'});
	
	$path = $Sys->Get('BBSPATH') . '/' . $Sys->Get('BBS') . '/kako';
	
	# �f�B���N�g�������擾
	EARENDIL::GetFolderHierarchy($path,\%Dirs);
	EARENDIL::GetFolderList(\%Dirs,\@dirList,'');
	
	foreach	$dir (@dirList){
		EARENDIL::GetFileList("$path/$dir",\@fileList,'(\d+)\.html');
		Add($this,0,0,0,$dir);
		foreach	$file (@fileList){
			@elem = split(/\./,$file);
			$subj = GetThreadSubject("$path/$dir/$file");
			if	($subj ne ''){
				Add($this,$elem[0],$subj,time(),$dir);
			}
		}
		undef(@fileList);
	}
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����Oindex�̍X�V
#	-------------------------------------------------------------------------------------
#	@param	$Sys	MELKOR
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub UpdateIndex
{
	my		$this = shift;
	my		($Sys,$Page) = @_;
	my		($Banner,%PATHES,@subDirs,@info,@dirs);
	my		($basePath,$path,$id,$dir,$key,$subj,$date);
	
	# ���m���ǂݍ���
	require('./module/denethor.pl');
	$Banner = new DENETHOR;
	$Banner->Load($Sys);
	
	$basePath = $Sys->Get('BBSPATH') . '/' . $Sys->Get('BBS');
	
	# �p�X���L�[�ɂ��ăn�b�V�����쐬
	foreach	$id (keys(%{$this->{'KEY'}})){
		$path = $this->{'PATH'}->{$id};
		$PATHES{$path} = $id;
	}
	@dirs = keys(%PATHES);
	unshift(@dirs,'');
	
	eval{
		# �p�X���Ƃ�index�𐶐�����
		foreach	$path (@dirs){
			# 1�K�w���̃T�u�t�H���_���擾����
			GetSubFolders($path,\@dirs,\@subDirs);
			foreach	$dir (sort(@subDirs)){
				push(@info,"0<>0<>0<>$dir");
			}
			
			# ���O�f�[�^������Ώ��z��ɒǉ�����
			foreach	$id (keys(%{$this->{'KEY'}})){
				if	($path eq $this->{'PATH'}->{$id} && $this->{'KEY'}->{$id} ne '0'){
					$key = $this->{'KEY'}->{$id};
					$subj = $this->{'SUBJECT'}->{$id};
					$date = $this->{'DATE'}->{$id};
					push(@info,"$key<>$subj<>$date<>$path");
				}
			}
			
			# index�t�@�C�����o�͂���
			$Page->Clear();
			OutputIndex($Sys,$Page,$Banner,\@info,$basePath,$path);
			
			undef(@info);
			undef(@subDirs);
		}
	};
}

#------------------------------------------------------------------------------------------------------------
#
#	�T�u�t�H���_���擾����
#	-------------------------------------------------------------------------------------
#	@param	$base	�e�t�H���_�p�X
#	@param	$pDirs	�f�B���N�g�����̔z��
#	@param	$pList	�T�u�t�H���_�i�[�z��
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub GetSubFolders
{
	my	($base,$pDirs,$pList) = @_;
	my	($dir,$old);
	
	$base .= '/';
	foreach	$dir (@$pDirs){
		$old = $dir;
		$old =~ s/^$base//;
		if	($old ne $dir){
			if	(!($old =~ /\//)){
				push(@$pList,$old);
			}
		}
	}
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����O�^�C�g���̎擾
#	-------------------------------------------------------------------------------------
#	@param	$path	�擾����t�@�C���̃p�X
#	@return	�^�C�g��
#
#------------------------------------------------------------------------------------------------------------
sub GetThreadSubject
{
	my		($path) = @_;
	my		($text);
	
	if	(-e $path){
		open(FILE,"<$path");
		foreach	$text (<FILE>){
			if	($text =~ /<title>(.*)<\/title>/){
				close(FILE);
				return $1;
			}
		}
	}
	close(FILE);
	return '';
}

#------------------------------------------------------------------------------------------------------------
#
#	�ߋ����Oindex���o�͂���
#	-------------------------------------------------------------------------------------
#	@param	$Sys	MELKOR
#	@param	$Page	THORIN
#	@param	$Banner	DENETHOR
#	@param	$pInfo	�o�͏��z��
#	@param	$base	�f���g�b�v�p�X
#	@param	$path	index�o�̓p�X
#	@return	�Ȃ�
#
#------------------------------------------------------------------------------------------------------------
sub OutputIndex
{
	my		($Sys,$Page,$Banner,$pInfo,$base,$path) = @_;
	my		(@elem,$info,$version);
	
	$version = $Sys->Get('VERSION');
	$bbsRoot = $Sys->Get('SERVER') . '/' . $Sys->Get('BBS');
	
	$Page->Print("<html><head><title>���낿���˂�ߋ����O�q�� - $path</title>\n");
	$Page->Print("</head><!--nobanner--><body>\n");
	
	# ���m���o��
	$Banner->Print($Page,100,2,0);
	
	$Page->Print("<table border><tr><th>KEY</th><th>subject</th><th>date</th></tr>\n");
	
	foreach	$info (@$pInfo){
		@elem = split(/<>/,$info);
		
		# �T�u�t�H���_���
		if	($elem[0] eq '0'){
			$Page->Print("<tr><td>Directory</td><td><a href=\"$elem[3]/index.html\">");
			$Page->Print("$elem[3]</a></td><td>-</td></tr>\n");
		}
		# �ߋ����O���
		else{
			$Page->Print("<tr><td>$elem[0]</td><td><a href=\"$elem[0].html\">");
			$Page->Print("$elem[1]</a></td><td>$elem[2]</td></tr>\n");
		}
	}
	$Page->Print("</table><hr>\n");
	$Page->Print("<a href=\"$bbsRoot/\">���f���ɖ߂遡</a> | ");
	$Page->Print("<a href=\"$bbsRoot/kako/\">���ߋ����O�g�b�v�ɖ߂遡</a> | ");
	$Page->Print("<a href=\"../\">��1��ɖ߂遡</a><hr>");
	$Page->Print("<div align=right><small><b>Powered by 0ch - build $version");
	$Page->Print("</b></div></small></body></html>\n");
	
	# index.html���o�͂���
	$Page->Flush(1,0666,"$base/kako$path/index.html");
}

#============================================================================================================
#	���W���[���I�[
#============================================================================================================
1;
